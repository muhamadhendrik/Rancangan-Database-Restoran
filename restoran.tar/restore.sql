--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.tb_transaksi DROP CONSTRAINT tb_transaksi_pkey;
ALTER TABLE ONLY public.orders DROP CONSTRAINT orders_pkey;
ALTER TABLE ONLY public.masakan DROP CONSTRAINT masakan_pkey;
ALTER TABLE ONLY public.levels DROP CONSTRAINT levels_pkey;
ALTER TABLE ONLY public.detail_order DROP CONSTRAINT detail_order_pkey;
DROP TABLE public.users;
DROP TABLE public.tb_transaksi;
DROP TABLE public.orders;
DROP TABLE public.masakan;
DROP TABLE public.levels;
DROP TABLE public.detail_order;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_order (
    id_detail_order character varying(20) NOT NULL,
    id_order character varying(20),
    id_masakan character varying(20),
    keterangan text,
    status_detail_order character varying(10)
);


ALTER TABLE detail_order OWNER TO postgres;

--
-- Name: levels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE levels (
    id_level integer NOT NULL,
    nama_level character varying(15)
);


ALTER TABLE levels OWNER TO postgres;

--
-- Name: masakan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE masakan (
    id_masakan character varying(20) NOT NULL,
    nama_masakan character varying(30),
    harga money,
    status_masakan character varying(10)
);


ALTER TABLE masakan OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE orders (
    id_order character varying(20) NOT NULL,
    no_meja integer,
    tanggal date,
    id_user integer,
    keterangan text,
    status_order character varying(30)
);


ALTER TABLE orders OWNER TO postgres;

--
-- Name: tb_transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_transaksi (
    id_transaksi character varying(20) NOT NULL,
    id_user integer,
    id_order character varying(20),
    tanggal date,
    total_bayar money
);


ALTER TABLE tb_transaksi OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE users (
    id_user integer NOT NULL,
    username character varying(50),
    password character varying(50),
    nama_user character varying(50),
    id_level integer
);


ALTER TABLE users OWNER TO postgres;

--
-- Data for Name: detail_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM stdin;
\.
COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM '$$PATH$$/2827.dat';

--
-- Data for Name: levels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY levels (id_level, nama_level) FROM stdin;
\.
COPY levels (id_level, nama_level) FROM '$$PATH$$/2826.dat';

--
-- Data for Name: masakan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY masakan (id_masakan, nama_masakan, harga, status_masakan) FROM stdin;
\.
COPY masakan (id_masakan, nama_masakan, harga, status_masakan) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orders (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM stdin;
\.
COPY orders (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM '$$PATH$$/2824.dat';

--
-- Data for Name: tb_transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM stdin;
\.
COPY tb_transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM '$$PATH$$/2823.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (id_user, username, password, nama_user, id_level) FROM stdin;
\.
COPY users (id_user, username, password, nama_user, id_level) FROM '$$PATH$$/2825.dat';

--
-- Name: detail_order detail_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_order
    ADD CONSTRAINT detail_order_pkey PRIMARY KEY (id_detail_order);


--
-- Name: levels levels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY levels
    ADD CONSTRAINT levels_pkey PRIMARY KEY (id_level);


--
-- Name: masakan masakan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY masakan
    ADD CONSTRAINT masakan_pkey PRIMARY KEY (id_masakan);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id_order);


--
-- Name: tb_transaksi tb_transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_transaksi
    ADD CONSTRAINT tb_transaksi_pkey PRIMARY KEY (id_transaksi);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id_user);


--
-- PostgreSQL database dump complete
--

